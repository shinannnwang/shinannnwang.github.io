*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  01_build_posting_sample.do
*
*  Builds the analysis sample for Tables 1-4 from the restricted job-posting
*  file. Keeps only the variables the tables use, and constructs the
*  occupation x country x year fixed effect (the source file provides
*  esco4_company_country_year but not esco4_country_year).
*
*  INPUT :  $posting_data                (restricted; not distributed)
*  OUTPUT:  $work/posting_sample.dta
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use logjob_total_skill remote_work work_experience education_level ///
    idsalary F_cognitive F_social_coworker F_customer_service F_tech ///
    physical_stringency_index esco4_company_country_year source2s BGcompanyid ///
    iso3 esco_level_4 year_grab_date ///
    using "$posting_data", clear

* Occupation x Country x Year fixed effect.
egen esco4_country_year = group(iso3 esco_level_4 year_grab_date)
drop iso3 esco_level_4 year_grab_date

compress
save "$work/posting_sample.dta", replace
di as result "posting_sample.dta built: " _N " observations."
