*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Figure 1. Proportion of Jobs Being Remote: Sorted by Month
*     Monthly mean of remote work over the estimation sample; vertical line = 2020.
*
*  INPUT :  $work/figure_sample.dta
*  OUTPUT:  $figures/fig1_remote_by_month.(gph|eps|png)
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use "$work/figure_sample.dta", clear

gen yearmonth = ym(year_grab_date, month_grab_date)
format yearmonth %tm

* Restrict to the estimation sample used throughout the paper.
areg work_experience remote_work i.year_grab_date if !missing(job_total_skill), ///
     absorb(esco4_country)
collapse remote_work if year_grab_date>=2018 & e(sample)==1, by(yearmonth) fast

twoway (scatter remote_work yearmonth, mcolor(black) msymbol(Oh)), ///
    graphregion(color(white)) legend(off) ///
    tlabel(2018m1(3)2021m3, labsize(small) angle(45)) ///
    ytitle("") xtitle("") xline(722) ytick(, notick)
graph save   "$figures/fig1_remote_by_month.gph", replace
graph export "$figures/fig1_remote_by_month.eps", replace
graph export "$figures/fig1_remote_by_month.png", replace width(1000)
di as result "Figure 1 complete."
