*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Figure 2. Proportion of Jobs Being Remote: Sorted by Country  (a) Pre / (b) Post
*
*  INPUT :  $work/figure_sample.dta , $data/iso3_iso2.dta (country-name crosswalk)
*  OUTPUT:  $figures/fig2a_country_pre.*, $figures/fig2b_country_post.*
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use "$work/figure_sample.dta", clear

collapse remote_work, by(iso3 post_covid) fast
merge m:1 iso3 using "$data/iso3_iso2.dta"
drop if _merge==2
drop _merge
replace countryname = "Netherlands" if countryname=="Netherlands (the)"
replace countryname = "United Kingdom" if countryname=="United Kingdom of Great Britain and Northern Ireland (the)"

* (a) Pre-COVID
graph bar remote_work if post_covid==0 & countryname!="Malta" & countryname!="Luxembourg", ///
    over(countryname, label(labsize(small) angle(45))) graphregion(color(white)) ///
    ytitle("") blabel(total, format(%9.2f)) bar(1, color(gray)) ///
    ylabel(0(0.05)0.22) ytick(, tstyle(none))
graph save   "$figures/fig2a_country_pre.gph", replace
graph export "$figures/fig2a_country_pre.eps", replace
graph export "$figures/fig2a_country_pre.png", replace width(1000)

* (b) Post-COVID
graph bar remote_work if post_covid==1 & countryname!="Malta" & countryname!="Luxembourg", ///
    over(countryname, label(labsize(small) angle(45))) graphregion(color(white)) ///
    ytitle("") blabel(total, format(%9.2f)) bar(1, color(gray)) ytick(, tstyle(none))
graph save   "$figures/fig2b_country_post.gph", replace
graph export "$figures/fig2b_country_post.eps", replace
graph export "$figures/fig2b_country_post.png", replace width(1000)
di as result "Figure 2 complete."
