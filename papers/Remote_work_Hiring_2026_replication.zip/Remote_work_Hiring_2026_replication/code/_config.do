*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- replication
*  _config.do : defines all folder paths from $reproot.
*
*  Every numbered script calls this file. When a script is run on its own
*  (not through master.do), it sets a default $reproot at its top and then
*  calls this file, so each script is self-contained.
*==============================================================================*

* If a script is launched standalone without master.do, $reproot may be unset.
if "$reproot" == "" {
    di as error "Set global reproot to the replication package folder before running."
    exit 198
}

global code    "$reproot/code"
global data    "$reproot/data"
global work    "$reproot/work"        // intermediate .dta files (not distributed)
global tables  "$reproot/output/tables"
global figures "$reproot/output/figures"

* Restricted Burning Glass / Lightcast job-posting file (NOT distributed).
* master.do sets this; if running a build script standalone, edit the path here.
if "$posting_data" == "" {
    global posting_data "/path/to/BGT_EU_nomissing_company.dta"
}
