*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Figure 4. Descriptive Differences Between Remote and In-Person Positions
*     Post-COVID clerical support occupations (esco_level_1==6): mean work
*     experience, educational level, and number of skills (log) by work mode.
*
*  INPUT :  $work/figure_sample.dta
*  OUTPUT:  $figures/fig4_descriptive.(gph|eps|png)
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use "$work/figure_sample.dta", clear

collapse education_level work_experience logjob_total_skill ///
    if esco_level_1==6 & post_covid==1, by(remote_work) fast
rename * A_*
rename A_remote_work remote_work
gen id = _n
reshape long A_, i(id) string
drop if remote_work==.
rename _j var
rename A_ mean
gen var3 = substr(var,1,3)
replace var = "1-work_experience"        if var=="work_experience"
replace var = "3-logjob_total_skill"   if var=="logjob_total_skill"
replace var = "2-education_level" if var=="education_level"
encode var, gen(vars)

cibar mean, over(remote_work vars) ciopts(lcolor(gs0)) barcol(gs5 gs10) ///
    graphopts(ylabel(, nogrid) graphregion(color(white)) ///
        legend(order(1 "Non-Remote Work" 2 "Remote Work")) ///
        ytitle("Avg. Level of Expected Employee Characteristics") ///
        ylabel(0(1)5, angle(0) grid) ///
        xla(1.5 "Work Experience" 4.2 "Educational Level" 6.8 "Num. of Skills (log)")) ///
    barlabel(on)
graph save   "$figures/fig4_descriptive.gph", replace
graph export "$figures/fig4_descriptive.eps", replace
graph export "$figures/fig4_descriptive.png", replace width(1000)
di as result "Figure 4 complete."
