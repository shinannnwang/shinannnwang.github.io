*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  06_build_figure_sample.do : compact sample for Figures 1-5
*
*  Figures 1-4 collapse the data destructively, so each figure script reloads
*  this compact file. Keeping only the needed variables makes reloads fast.
*
*  INPUT :  $posting_data                (restricted; not distributed)
*  OUTPUT:  $work/figure_sample.dta
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use year_grab_date month_grab_date work_experience remote_work ///
    job_total_skill logjob_total_skill education_level ///
    esco4_country esco4_company_country esco_level_1 esco_level_4 iso3 ///
    post_covid source2s BGcompanyid days_posted ///
    mean_on_the_job_training_level IM_Independence unemployment_nuts2_combine trust ///
    using "$posting_data", clear

compress
save "$work/figure_sample.dta", replace
di as result "figure_sample.dta built: " _N " observations."
