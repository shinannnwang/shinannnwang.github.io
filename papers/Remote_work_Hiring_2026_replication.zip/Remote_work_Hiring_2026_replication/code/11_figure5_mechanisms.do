*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Figure 5. Testing Mechanisms: Different Moderators
*     Remote-work coefficient on log(number of skills) at +/-1 SD of each moderator.
*     Panel A (5a): on-the-job training, importance of independence
*     Panel B (5b): hard-to-fill jobs (time-to-fill), unemployment rate, trust
*     FE (both panels): Occupation x Employer x Country + Job portal, year controls.
*
*  INPUT :  $work/figure_sample.dta
*  OUTPUT:  $figures/fig5a_training_independence.*, $figures/fig5b_days_unemp_trust.*
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

*------------------------------------------------------------------------------*
* Panel A: training support & independence
*------------------------------------------------------------------------------*
use "$work/figure_sample.dta", clear
matrix coef_results = J(4, 3, .)
local i = 1

reghdfe logjob_total_skill remote_work##c.mean_on_the_job_training_level ///
    i.year_grab_date if !missing(logjob_total_skill), ///
    absorb(source2s esco4_company_country) cluster(BGcompanyid)
sum mean_on_the_job_training_level if e(sample)
local m1 = r(mean)
local s1 = r(sd)
lincom _b[1.remote_work] + (`m1' + `s1') * _b[1.remote_work#c.mean_on_the_job_training_level]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)
local ++i
lincom _b[1.remote_work] + (`m1' - `s1') * _b[1.remote_work#c.mean_on_the_job_training_level]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)
local ++i

reghdfe logjob_total_skill remote_work##c.IM_Independence ///
    i.year_grab_date if !missing(logjob_total_skill), ///
    absorb(source2s esco4_company_country) cluster(BGcompanyid)
sum IM_Independence if e(sample)
local m2 = r(mean)
local s2 = r(sd)
lincom _b[1.remote_work] + (`m2' + `s2') * _b[1.remote_work#c.IM_Independence]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)
local ++i
lincom _b[1.remote_work] + (`m2' - `s2') * _b[1.remote_work#c.IM_Independence]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)

matrix colnames coef_results = Coef CI_Lower CI_Upper
matrix rownames coef_results = Training_High Training_Low Independence_High Independence_Low
matrix list coef_results

svmat coef_results, names(col)
gen varname = ""
replace varname = "On-the-Job Training"        in 1
replace varname = "On-the-Job Training"        in 2
replace varname = "Importance of Independence" in 3
replace varname = "Importance of Independence" in 4
gen condition = ""
replace condition = "High" in 1
replace condition = "Low"  in 2
replace condition = "High" in 3
replace condition = "Low"  in 4
keep Coef CI_Lower CI_Upper varname condition
keep in 1/4
save "$work/mechanism_coef_training.dta", replace

gen varname_id = .
replace varname_id = 0.5 if varname=="On-the-Job Training"
replace varname_id = 1.5 if varname=="Importance of Independence"
gen varname_shift = .
replace varname_shift = varname_id - 0.05 if condition=="Low"
replace varname_shift = varname_id + 0.05 if condition=="High"

twoway ///
    (rcap CI_Upper CI_Lower varname_shift if condition=="High", lcolor(red)) ///
    (scatter Coef varname_shift if condition=="High", mcolor(red) msymbol(circle)) ///
    (rcap CI_Upper CI_Lower varname_shift if condition=="Low", lcolor(blue)) ///
    (scatter Coef varname_shift if condition=="Low", mcolor(blue) msymbol(triangle_hollow)), ///
    xlabel(0.5 "On-the-Job Training" 1.5 "Importance of Independence", noticks) ///
    xtitle("") ytitle("Change in Skill Requirements") yline(0, lcolor(gs12)) ///
    legend(order(4 "Low" 2 "High")) graphregion(color(white)) xscale(range(0 2))
graph save   "$figures/fig5a_training_independence.gph", replace
graph export "$figures/fig5a_training_independence.eps", replace
graph export "$figures/fig5a_training_independence.png", replace width(1000)

*------------------------------------------------------------------------------*
* Panel B: hard-to-fill jobs, unemployment, trust
*          (employer x occupation x country FE + job portal, matching Panel A)
*------------------------------------------------------------------------------*
use "$work/figure_sample.dta", clear
gen days_posted2020 = days_posted if year_grab_date<2020
bys esco_level_4:             egen days_posted2020_esco4      = mean(days_posted2020)
bys esco_level_4 BGcompanyid: egen days_posted2020_esco4_firm = mean(days_posted2020)
gen ldays_posted2020_esco4_firm = log(days_posted2020_esco4_firm)

matrix coef_results = J(6, 3, .)
local i = 1

reghdfe logjob_total_skill remote_work##c.ldays_posted2020_esco4_firm ///
    i.year_grab_date if !missing(logjob_total_skill), absorb(source2s esco4_company_country) cluster(BGcompanyid)
sum ldays_posted2020_esco4_firm if e(sample)
local m1 = r(mean)
local s1 = r(sd)
lincom _b[1.remote_work] + (`m1' + `s1') * _b[1.remote_work#c.ldays_posted2020_esco4_firm]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)
local ++i
lincom _b[1.remote_work] + (`m1' - `s1') * _b[1.remote_work#c.ldays_posted2020_esco4_firm]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)
local ++i

reghdfe logjob_total_skill remote_work##c.unemployment_nuts2_combine ///
    i.year_grab_date if !missing(logjob_total_skill), absorb(source2s esco4_company_country) cluster(BGcompanyid)
sum unemployment_nuts2_combine if e(sample)
local m2 = r(mean)
local s2 = r(sd)
lincom _b[1.remote_work] + (`m2' + `s2') * _b[1.remote_work#c.unemployment_nuts2_combine]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)
local ++i
lincom _b[1.remote_work] + (`m2' - `s2') * _b[1.remote_work#c.unemployment_nuts2_combine]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)
local ++i

reghdfe logjob_total_skill remote_work##c.trust ///
    i.year_grab_date if !missing(logjob_total_skill), absorb(source2s esco4_company_country) cluster(BGcompanyid)
sum trust if e(sample)
local m3 = r(mean)
local s3 = r(sd)
lincom _b[1.remote_work] + (`m3' + `s3') * _b[1.remote_work#c.trust]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)
local ++i
lincom _b[1.remote_work] + (`m3' - `s3') * _b[1.remote_work#c.trust]
matrix coef_results[`i',1] = r(estimate)
matrix coef_results[`i',2] = r(estimate) - 1.96*r(se)
matrix coef_results[`i',3] = r(estimate) + 1.96*r(se)

matrix colnames coef_results = Coef CI_Lower CI_Upper
matrix rownames coef_results = LogDays_High LogDays_Low Unemp_High Unemp_Low Trust_High Trust_Low
matrix list coef_results

svmat coef_results, names(col)
gen varname = ""
replace varname = "Hard-to-Fill Jobs" in 1
replace varname = "Hard-to-Fill Jobs" in 2
replace varname = "Unemployment Rate" in 3
replace varname = "Unemployment Rate" in 4
replace varname = "Generalized Trust" in 5
replace varname = "Generalized Trust" in 6
gen condition = ""
replace condition = "High" in 1
replace condition = "Low"  in 2
replace condition = "High" in 3
replace condition = "Low"  in 4
replace condition = "High" in 5
replace condition = "Low"  in 6
keep Coef CI_Lower CI_Upper varname condition
keep in 1/6
save "$work/mechanism_coef_others.dta", replace

gen varname_id = .
replace varname_id = 0.5 if varname=="Hard-to-Fill Jobs"
replace varname_id = 1.5 if varname=="Unemployment Rate"
replace varname_id = 2.5 if varname=="Generalized Trust"
gen varname_shift = .
replace varname_shift = varname_id - 0.05 if condition=="Low"
replace varname_shift = varname_id + 0.05 if condition=="High"

twoway ///
    (rcap CI_Upper CI_Lower varname_shift if condition=="High", lcolor(red)) ///
    (scatter Coef varname_shift if condition=="High", mcolor(red) msymbol(circle)) ///
    (rcap CI_Upper CI_Lower varname_shift if condition=="Low", lcolor(blue)) ///
    (scatter Coef varname_shift if condition=="Low", mcolor(blue) msymbol(triangle_hollow)), ///
    xlabel(0.5 "Hard-to-Fill Jobs" 1.5 "Unemployment Rate" 2.5 "Generalized Trust", noticks) ///
    xtitle("") ytitle("Change in Skill Requirements") yline(0, lcolor(gs12)) ///
    legend(order(4 "Low" 2 "High")) graphregion(color(white)) xscale(range(0 3))
graph save   "$figures/fig5b_days_unemp_trust.gph", replace
graph export "$figures/fig5b_days_unemp_trust.eps", replace
graph export "$figures/fig5b_days_unemp_trust.png", replace width(1000)
di as result "Figure 5 complete."
