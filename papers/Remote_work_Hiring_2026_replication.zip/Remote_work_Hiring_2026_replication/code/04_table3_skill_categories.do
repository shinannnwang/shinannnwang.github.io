*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Table 3. Linear Estimation of Hiring Skill Requirements: Separated by Category
*
*  Outcomes : cognitive, social (coworkers), social (customers), technical skills
*  Treatment: remote_work  (with and without number of skills (log))
*  FE       : Occupation x Employer x Country x Year + Job portal
*  SE       : clustered at the firm level (BGcompanyid)
*
*  INPUT :  $work/posting_sample.dta
*  OUTPUT:  $tables/table3_skill_categories.tex
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use "$work/posting_sample.dta", clear
local touse if !missing(logjob_total_skill)
local fe    source2s esco4_company_country_year

reghdfe F_cognitive remote_work `touse', absorb(`fe') cluster(BGcompanyid)
est store e1
reghdfe F_cognitive remote_work logjob_total_skill `touse', absorb(`fe') cluster(BGcompanyid)
est store e2
reghdfe F_social_coworker remote_work `touse', absorb(`fe') cluster(BGcompanyid)
est store e3
reghdfe F_social_coworker remote_work logjob_total_skill `touse', absorb(`fe') cluster(BGcompanyid)
est store e4
reghdfe F_customer_service remote_work `touse', absorb(`fe') cluster(BGcompanyid)
est store e5
reghdfe F_customer_service remote_work logjob_total_skill `touse', absorb(`fe') cluster(BGcompanyid)
est store e6
reghdfe F_tech remote_work `touse', absorb(`fe') cluster(BGcompanyid)
est store e7
reghdfe F_tech remote_work logjob_total_skill `touse', absorb(`fe') cluster(BGcompanyid)
est store e8

label var remote_work "Remote work"
label var logjob_total_skill     "Number of skills (log)"

estadd local jfcyfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8
estadd local sfixed    "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8

esttab e1 e2 e3 e4 e5 e6 e7 e8 using "$tables/table3_skill_categories.tex", replace ///
    label se r2 wrap width(\hsize) ///
    title("\label{tab:category} Linear Estimation of Hiring Skill Requirements: Separated by Skill Categories") ///
    mgroups("Cognitive Skills" "Social Interaction with Coworkers" "Social Interaction with Customers" "Technical Skills", ///
        pattern(1 0 1 0 1 0 1 0) ///
        prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    nomtitles noomitted keep(remote_work logjob_total_skill) ///
    order(remote_work logjob_total_skill) ///
    scalar("hello Fixed Effects:" ///
           "jfcyfixed Occupation x Employer x Country x Year" ///
           "sfixed Job Portal")

esttab e1 e2 e3 e4 e5 e6 e7 e8, se r2 keep(remote_work logjob_total_skill)
di as result "Table 3 complete."
