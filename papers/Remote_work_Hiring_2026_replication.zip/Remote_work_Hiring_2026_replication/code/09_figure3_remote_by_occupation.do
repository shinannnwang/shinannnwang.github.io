*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Figure 3. Proportion of Jobs Being Remote: Sorted by Occupation (a) Pre / (b) Post
*     Occupation = ESCO major group (esco_level_1).
*
*  INPUT :  $work/figure_sample.dta
*  OUTPUT:  $figures/fig3a_occupation_pre.*, $figures/fig3b_occupation_post.*
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use "$work/figure_sample.dta", clear

* Restrict to the estimation sample, then collapse by occupation x COVID period.
areg work_experience remote_work i.year_grab_date if !missing(job_total_skill), ///
     absorb(esco4_country)
collapse remote_work if e(sample)==1, by(esco_level_1 post_covid) fast
drop if post_covid==.

rename esco_level_1 esco_level_1a
decode esco_level_1a, gen(esco_level_1)
replace esco_level_1 = "Technicians"                  if esco_level_1=="Technicians and associate professionals"
replace esco_level_1 = "Skilled agricultural workers" if esco_level_1=="Skilled agricultural, forestry and fishery workers"
replace esco_level_1 = "Craft workers"                if esco_level_1=="Craft and related trades workers"
replace esco_level_1 = "Plant and machine operators"  if esco_level_1=="Plant and machine operators, and assemblers"
replace esco_level_1 = "Clerical support"             if esco_level_1=="Clerical support workers"
drop if missing(esco_level_1)

* (a) Pre-COVID
graph bar remote_work if post_covid==0, ///
    over(esco_level_1, label(labsize(medsmall) angle(45))) graphregion(color(white)) ///
    blabel(total, format(%9.2f)) bar(1, color(gray)) ylabel(0(0.05)0.15) ytick(, tstyle(none)) ytitle("")
graph save   "$figures/fig3a_occupation_pre.gph", replace
graph export "$figures/fig3a_occupation_pre.eps", replace
graph export "$figures/fig3a_occupation_pre.png", replace width(1000)

* (b) Post-COVID
graph bar remote_work if post_covid==1, ///
    over(esco_level_1, label(labsize(medsmall) angle(45))) graphregion(color(white)) ///
    blabel(total, format(%9.2f)) bar(1, color(gray)) ylabel(0(0.05)0.15) ytick(, tstyle(none)) ytitle("")
graph save   "$figures/fig3b_occupation_post.gph", replace
graph export "$figures/fig3b_occupation_post.eps", replace
graph export "$figures/fig3b_occupation_post.png", replace width(1000)
di as result "Figure 3 complete."
