*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Table 2. Instrumental Variable Estimation of Hiring Requirements
*
*  Instrument: physical_stringency_index (social distancing x physical interaction)
*  Cols 1-2  : first stage (remote work on the instrument)
*  Cols 3-8  : 2SLS of skills (log), work experience, educational level on remote work
*  FE        : (odd cols)  Occupation x Country x Year
*              (even cols) Occupation x Employer x Country x Year + Job portal
*  SE        : clustered at the firm level (BGcompanyid)
*
*  INPUT :  $work/posting_sample.dta
*  OUTPUT:  $tables/table2_iv_estimates.tex
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use "$work/posting_sample.dta", clear
local touse if !missing(logjob_total_skill) & !missing(BGcompanyid)

* First stage: remote work on the instrument
reghdfe remote_work physical_stringency_index `touse', ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e1
reghdfe remote_work physical_stringency_index `touse', ///
        absorb(source2s esco4_company_country_year) cluster(BGcompanyid)
est store e2

* 2SLS: number of skills (log)
ivreghdfe logjob_total_skill (remote_work = physical_stringency_index) `touse', ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e3
ivreghdfe logjob_total_skill (remote_work = physical_stringency_index) `touse', ///
        absorb(esco4_company_country_year source2s) cluster(BGcompanyid)
est store e4

* 2SLS: work experience
ivreghdfe work_experience (remote_work = physical_stringency_index) `touse', ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e5
ivreghdfe work_experience (remote_work = physical_stringency_index) `touse', ///
        absorb(esco4_company_country_year source2s) cluster(BGcompanyid)
est store e6

* 2SLS: educational level
ivreghdfe education_level (remote_work = physical_stringency_index) `touse', ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e7
ivreghdfe education_level (remote_work = physical_stringency_index) `touse', ///
        absorb(esco4_company_country_year source2s) cluster(BGcompanyid)
est store e8

label var remote_work     "Remote work"
label var physical_stringency_index "Social distancing index x Physical interaction"

estadd local jcyfixed  "Yes", replace: e1 e3 e5 e7
estadd local jfcyfixed "Yes", replace: e2 e4 e6 e8
estadd local sfixed    "Yes", replace: e2 e4 e6 e8

esttab e1 e2 e3 e4 e5 e6 e7 e8 using "$tables/table2_iv_estimates.tex", replace ///
    label se r2 wrap width(\hsize) ///
    title("\label{tab:remoteiv1} Instrumental Variable Estimation of Hiring Requirements") ///
    mgroups("First Stage: Remote Work" "Num. of Skills (log)" "Work Exp. (in Years)" "Educational Level", ///
        pattern(1 0 1 0 1 0 1 0) ///
        prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    nomtitles noomitted keep(remote_work physical_stringency_index) ///
    order(remote_work physical_stringency_index) ///
    scalar("hello Fixed Effects:" ///
           "jcyfixed Occupation x Country x Posting Year" ///
           "jfcyfixed Occupation x Employer x Country x Posting Year" ///
           "sfixed Job Portal")

esttab e1 e2 e3 e4 e5 e6 e7 e8, se r2 keep(remote_work physical_stringency_index)
di as result "Table 2 complete."
