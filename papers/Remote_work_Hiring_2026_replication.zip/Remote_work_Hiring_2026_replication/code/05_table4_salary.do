*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Table 4. Linear Estimation of Job Posting Salary
*
*  Outcome  : idsalary
*  Cols 1-4 : OLS (with/without controls; areg = OCC x Country x Year,
*             reghdfe = OCC x Employer x Country x Year + Job portal)
*  Cols 5-6 : 2SLS with remote work instrumented by physical_stringency_index
*  SE       : clustered at the firm level (BGcompanyid)
*
*  INPUT :  $work/posting_sample.dta
*  OUTPUT:  $tables/table4_salary.tex
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use "$work/posting_sample.dta", clear
local touse if !missing(logjob_total_skill)

* OLS
areg    idsalary remote_work `touse', ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e1
reghdfe idsalary remote_work `touse', ///
        absorb(source2s esco4_company_country_year) cluster(BGcompanyid)
est store e2
areg    idsalary remote_work logjob_total_skill work_experience education_level `touse', ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e3
reghdfe idsalary remote_work logjob_total_skill work_experience education_level `touse', ///
        absorb(source2s esco4_company_country_year) cluster(BGcompanyid)
est store e4

* 2SLS
ivreghdfe idsalary (remote_work = physical_stringency_index) ///
        if !missing(logjob_total_skill) & !missing(BGcompanyid), ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e5
ivreghdfe idsalary (remote_work = physical_stringency_index) ///
        if !missing(logjob_total_skill) & !missing(BGcompanyid), ///
        absorb(esco4_company_country_year source2s) cluster(BGcompanyid)
est store e6

label var remote_work "Remote work"
label var logjob_total_skill     "Number of skills (log)"
label var work_experience          "Work experience"
label var education_level   "Educational level"

estadd local jcyfixed  "Yes", replace: e1 e3 e5
estadd local jfcyfixed "Yes", replace: e2 e4 e6
estadd local sfixed    "Yes", replace: e2 e4 e6

esttab e1 e2 e3 e4 e5 e6 using "$tables/table4_salary.tex", replace ///
    label se r2 wrap width(\hsize) ///
    title("\label{tab:wage} Linear Estimation of Job Posting Salary") ///
    mgroups("OLS" "IV", pattern(1 0 0 0 1 0) ///
        prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    nomtitles noomitted ///
    keep(remote_work work_experience education_level logjob_total_skill) ///
    order(remote_work work_experience education_level logjob_total_skill) ///
    scalar("hello Fixed Effects:" ///
           "jcyfixed Occupation x Country x Year" ///
           "jfcyfixed Occupation x Employer x Country x Year" ///
           "sfixed Job Portal")

esttab e1 e2 e3 e4 e5 e6, se r2 keep(remote_work work_experience education_level logjob_total_skill)
di as result "Table 4 complete."
