*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Figure 6 & Table 6. Supplementary Analysis: An Online Experiment
*
*  Between-subjects design: each participant is randomly assigned ONE occupation
*  (data scientist / marketing analyst / sales) x ONE work mode (remote / onsite)
*  x ONE outcome block (skill / experience / education). The outcome (q5) is on a
*  1-4 scale within its block.
*
*  INPUT :  $data/experiment/remote_work1400_clean.csv   (included in package)
*  OUTPUT:  Figure 6 -> $figures/fig6a_skill.*, fig6b_experience.*, fig6c_education.*,
*                       fig6_combined.*
*           Table 6  -> $tables/table6_experiment.tex
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

*------------------------------------------------------------------------------*
* 1. Import raw Qualtrics export and restore variable names by position.
*    (The export header names only the first 9 of 20 columns.)
*------------------------------------------------------------------------------*
import delimited "$data/experiment/remote_work1400_clean.csv", clear bindquote(strict) varnames(1)

rename q1  id            // column [1] is the participant id, not a question
rename v3  q1            // column [2] is the real Q1
rename v10 q8            // consent question
rename v11 q9            // gender
rename v12 q10           // age
rename v13 q11           // education
rename v14 q12           // hiring experience
rename v15 q13           // country
rename v16 q14           // industry
rename v17 q15           // occupation
rename v18 q16           // remote hiring
drop  v19                // duplicate participant id
rename v20 condition     // assigned experimental condition

gen educ  = strpos(condition, "educ")  > 0
gen exp   = strpos(condition, "exp")   > 0
gen skill = strpos(condition, "skill") > 0

*------------------------------------------------------------------------------*
* 2. Sample cleaning: speeders, non-consent, and failed attention checks.
*------------------------------------------------------------------------------*
drop if durationinseconds <= 60
drop if q8 == "Not sure, maybe or maybe not" | q8 == "No, I have not and please remove data"

gen attention_occ = "Data scientist"        if strpos(q7, "Data scientist")   > 0
replace attention_occ = "Sales"             if strpos(q7, "Sale representative") > 0
replace attention_occ = "Marketing analyst" if strpos(q7, "Marketing analyst")   > 0
gen condition_occ = "Data scientist"        if strpos(condition, "data_scientist") > 0
replace condition_occ = "Marketing analyst" if strpos(condition, "market_analyst") > 0
replace condition_occ = "Sales"             if strpos(condition, "sale")          > 0
gen attention_remote = 1 if strpos(q7, "remote") > 0
replace attention_remote = 0 if strpos(q7, "person") > 0
gen condition_remote = 1 if strpos(condition, "remote") > 0
replace condition_remote = 0 if strpos(condition, "onsite") > 0
drop if attention_occ    != condition_occ
drop if attention_remote != condition_remote

gen remote = 1 if strpos(condition, "remote") > 0
replace remote = 0 if strpos(condition, "onsite") > 0
gen occupation = "Data scientist"           if strpos(condition, "data_scientist") > 0
replace occupation = "Marketing analyst"    if strpos(condition, "market_analyst") > 0
replace occupation = "Sales representative" if strpos(condition, "sales")          > 0
encode occupation, gen(occupation_code)
save "$work/experiment_clean.dta", replace

*------------------------------------------------------------------------------*
* 3. Build the three outcome measures (each 1-4), then stack them.
*------------------------------------------------------------------------------*
use "$work/experiment_clean.dta", clear
keep if skill == 1
gen skill_level = .
replace skill_level = 1 if q5 == "None"
replace skill_level = 2 if q5 == "Only the most essential skills for this position"
replace skill_level = 3 if q5 == "Most relevant skills for this position"
replace skill_level = 4 if q5 == "All relevant skills for this position"
keep id remote occupation occupation_code skill_level
save "$work/exp_skill.dta", replace

use "$work/experiment_clean.dta", clear
keep if exp == 1
gen experience_level = .
replace experience_level = 1 if q5 == "0"
replace experience_level = 2 if q5 == "1-2 years"
replace experience_level = 3 if q5 == "3-5 years"
replace experience_level = 4 if q5 == "5+ years"
keep id remote occupation occupation_code experience_level
save "$work/exp_experience.dta", replace

use "$work/experiment_clean.dta", clear
keep if educ == 1
gen education_level = .
replace education_level = 1 if q5 == "high school degree"
replace education_level = 2 if q5 == "vocational or associate degree"
replace education_level = 3 if q5 == "bachelor's degree"
replace education_level = 4 if q5 == "graduate degree"
keep id remote occupation occupation_code education_level
save "$work/exp_education.dta", replace

use "$work/exp_skill.dta", clear
append using "$work/exp_experience.dta"
append using "$work/exp_education.dta"
save "$work/experiment_final.dta", replace

*------------------------------------------------------------------------------*
* 4. FIGURE 6 -- descriptive means with 95% CIs, by work mode x occupation.
*------------------------------------------------------------------------------*
local gopts ylabel(, nogrid) graphregion(color(white)) ylabel(1(1)4, angle(0) grid) ytitle("") xtitle("")
local leg legend(order(1 "In-person Position" 2 "Remote Position") pos(6))

cibar skill_level, over(remote occupation_code) ciopts(lcolor(gs0)) barcol(gs5 gs10) barlabel(on) bargap(10) ///
    graphopts(title("(a) Skill requirement") `gopts' `leg')
graph save   "$figures/fig6a_skill.gph", replace
graph export "$figures/fig6a_skill.eps", replace

cibar experience_level, over(remote occupation_code) ciopts(lcolor(gs0)) barcol(gs5 gs10) barlabel(on) bargap(10) ///
    graphopts(title("(b) Work experience") `gopts' `leg')
graph save   "$figures/fig6b_experience.gph", replace
graph export "$figures/fig6b_experience.eps", replace

cibar education_level, over(remote occupation_code) ciopts(lcolor(gs0)) barcol(gs5 gs10) barlabel(on) bargap(10) ///
    graphopts(title("(c) Educational credential") `gopts' `leg')
graph save   "$figures/fig6c_education.gph", replace
graph export "$figures/fig6c_education.eps", replace

graph combine "$figures/fig6a_skill.gph" "$figures/fig6b_experience.gph" "$figures/fig6c_education.gph", ///
    cols(1) graphregion(color(white)) xsize(6) ysize(9)
graph save   "$figures/fig6_combined.gph", replace
graph export "$figures/fig6_combined.eps", replace

*------------------------------------------------------------------------------*
* 5. TABLE 6 -- OLS on remote work with occupation FE, SEs clustered by participant.
*------------------------------------------------------------------------------*
use "$work/experiment_final.dta", clear
label var remote "Remote work"

reg skill_level      remote i.occupation_code, cluster(id)
est store e1
reg experience_level remote i.occupation_code, cluster(id)
est store e2
reg education_level     remote i.occupation_code, cluster(id)
est store e3

estadd local jfixed "Yes", replace: e1 e2 e3

esttab e1 e2 e3 using "$tables/table6_experiment.tex", replace label se r2 wrap width(\hsize) ///
    title("\label{tab:exp_result} Supplementary Analysis: An Online Experiment") ///
    mgroups("Skill Requirement" "Work Experience" "Educational Credential", pattern(1 1 1) ///
        prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    nomtitles noomitted keep(remote) order(remote) ///
    scalar("hello Fixed Effects:" "jfixed Occupation")

esttab e1 e2 e3, se r2 keep(remote) mtitles("Skill" "Experience" "Education")
di as result "Figure 6 and Table 6 complete."
