*==============================================================================*
*  Wang, Zhang, and Liao (2026) -- "Remote Work and Hiring" (ASQ)
*  Table 1. Linear Estimation of Hiring Requirements
*
*  Outcomes : number of skills (log), work experience, educational level
*  Treatment: remote_work
*  FE       : (odd cols)  Occupation x Country x Year               [areg]
*             (even cols) Occupation x Employer x Country x Year
*                         + Job portal                              [reghdfe]
*  SE       : clustered at the firm level (BGcompanyid)
*
*  INPUT :  $work/posting_sample.dta
*  OUTPUT:  $tables/table1_hiring_requirements.tex
*==============================================================================*

clear all
set more off
if "$reproot" == "" global reproot "/path/to/Remote_work_Hiring_2026_replication"
do "$reproot/code/_config.do"

use "$work/posting_sample.dta", clear

* Number of skills (log)
areg    logjob_total_skill remote_work if !missing(logjob_total_skill), ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e1
reghdfe logjob_total_skill remote_work if !missing(logjob_total_skill), ///
        absorb(source2s esco4_company_country_year) cluster(BGcompanyid)
est store e2

* Work experience (with and without controlling for number of skills)
areg    work_experience remote_work if !missing(logjob_total_skill), ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e3
reghdfe work_experience remote_work if !missing(logjob_total_skill), ///
        absorb(source2s esco4_company_country_year) cluster(BGcompanyid)
est store e4
areg    work_experience remote_work logjob_total_skill if !missing(logjob_total_skill), ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e5
reghdfe work_experience remote_work logjob_total_skill if !missing(logjob_total_skill), ///
        absorb(source2s esco4_company_country_year) cluster(BGcompanyid)
est store e6

* Educational level (with and without controlling for number of skills)
areg    education_level remote_work if !missing(logjob_total_skill), ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e7
reghdfe education_level remote_work if !missing(logjob_total_skill), ///
        absorb(source2s esco4_company_country_year) cluster(BGcompanyid)
est store e8
areg    education_level remote_work logjob_total_skill if !missing(logjob_total_skill), ///
        absorb(esco4_country_year) cluster(BGcompanyid)
est store e9
reghdfe education_level remote_work logjob_total_skill if !missing(logjob_total_skill), ///
        absorb(source2s esco4_company_country_year) cluster(BGcompanyid)
est store e10

label var remote_work "Remote work"
label var logjob_total_skill     "Number of skills (log)"

estadd local jcyfixed  "Yes", replace: e1 e3 e5 e7 e9
estadd local jfcyfixed "Yes", replace: e2 e4 e6 e8 e10
estadd local sfixed    "Yes", replace: e2 e4 e6 e8 e10

esttab e1 e2 e3 e4 e5 e6 e7 e8 e9 e10 using "$tables/table1_hiring_requirements.tex", replace ///
    label se r2 wrap width(\hsize) ///
    title("\label{tab:remote1} Linear Estimation of Hiring Requirements") ///
    mgroups("Num. of Skills (log)" "Work Experience" "Educational Level", ///
        pattern(1 0 1 0 0 0 1 0 0 0) ///
        prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
    nomtitles noomitted keep(remote_work logjob_total_skill) ///
    order(remote_work logjob_total_skill) ///
    scalar("hello Fixed Effects:" ///
           "jcyfixed Occupation x Country x Year" ///
           "jfcyfixed Occupation x Employer x Country x Year" ///
           "sfixed Job Portal")

esttab e1 e2 e3 e4 e5 e6 e7 e8 e9 e10, se r2 keep(remote_work logjob_total_skill)
di as result "Table 1 complete."
