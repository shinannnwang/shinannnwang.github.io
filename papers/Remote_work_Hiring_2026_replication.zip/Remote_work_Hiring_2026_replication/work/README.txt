Intermediate .dta files are written here at run time (not distributed).
