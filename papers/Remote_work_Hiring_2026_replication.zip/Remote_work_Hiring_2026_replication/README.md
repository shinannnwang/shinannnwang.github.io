# Replication Package

**Wang, Zhang, and Liao (2026), "Remote Work and Hiring,"** *Administrative Science Quarterly.*

This package contains all code to reproduce the tables and figures in the paper,
together with the online-experiment data. The job-posting data are proprietary and
cannot be redistributed (see **Data availability** below).

---

## 1. Contents

```
Remote_work_Hiring_2026_replication/
├── master.do                     # runs the entire package in order
├── README.md
├── code/
│   ├── _config.do                # defines folder paths (called by every script)
│   ├── 01_build_posting_sample.do
│   ├── 02_table1_hiring_requirements.do
│   ├── 03_table2_iv_estimates.do
│   ├── 04_table3_skill_categories.do
│   ├── 05_table4_salary.do
│   ├── 06_build_figure_sample.do
│   ├── 07_figure1_remote_by_month.do
│   ├── 08_figure2_remote_by_country.do
│   ├── 09_figure3_remote_by_occupation.do
│   ├── 10_figure4_descriptive.do
│   ├── 11_figure5_mechanisms.do
│   └── 12_figure6_table6_experiment.do
├── data/
│   ├── experiment/
│   │   └── remote_work1400_clean.csv   # online-experiment micro-data (included)
│   └── iso3_iso2.dta                       # country-name crosswalk (Figure 2)
├── work/                          # intermediate .dta files (created at run time)
└── output/
    ├── tables/                    # .tex tables written here
    └── figures/                   # .eps / .png / .gph figures written here
```

## 2. Script-to-exhibit map

| Script | Produces |
|--------|----------|
| `01_build_posting_sample.do` | analysis sample for Tables 1–4 (from restricted data) |
| `02_table1_hiring_requirements.do` | **Table 1** |
| `03_table2_iv_estimates.do` | **Table 2** |
| `04_table3_skill_categories.do` | **Table 3** |
| `05_table4_salary.do` | **Table 4** |
| `06_build_figure_sample.do` | analysis sample for Figures 1–5 (from restricted data) |
| `07_figure1_remote_by_month.do` | **Figure 1** |
| `08_figure2_remote_by_country.do` | **Figure 2** (a) & (b) |
| `09_figure3_remote_by_occupation.do` | **Figure 3** (a) & (b) |
| `10_figure4_descriptive.do` | **Figure 4** |
| `11_figure5_mechanisms.do` | **Figure 5** (a) & (b) |
| `12_figure6_table6_experiment.do` | **Figure 6** and **Table 6** |

(Tables 5 and the online appendix are not part of this package.)

## 3. Software

- Stata 17 or later.
- User-written packages (install once from SSC):
  ```
  ssc install reghdfe,  replace
  ssc install ivreghdfe, replace
  ssc install ftools,    replace
  ssc install estout,    replace
  ssc install cibar,     replace
  ```

## 4. How to run

1. Open `master.do` and set the two paths at the top:
   - `$reproot` — the folder where this package lives.
   - `$posting_data` — your licensed copy of the job-posting file (only needed for
     Tables 1–4 and Figures 1–5).
2. Run `master.do`. It executes scripts 01–12 in order and writes results to
   `output/tables` and `output/figures`.

Each script can also be run on its own: set `$reproot` at the top of the script (or
in the Stata session) and it will call `_config.do` to resolve the remaining paths.

**Runtime note.** The job-posting regressions absorb high-dimensional fixed effects
(occupation × employer × country × year) over ~50 million postings. Several models
take tens of minutes to over an hour each; a machine with ample RAM (≥64 GB) is
recommended. The online-experiment step (script 12) runs in seconds.

## 5. Data availability

- **Online experiment** — included: `data/experiment/remote_work1400_clean.csv`.
  Scripts 12 (Figure 6, Table 6) run out of the box.
- **Job postings** — the analyses in Tables 1–4 and Figures 1–5 use proprietary
  job-posting data from Burning Glass Technologies / Lightcast, obtained under
  license. These data **cannot be redistributed** and are therefore **not included**.
  Researchers with a Lightcast license can reconstruct the source file and point
  `$posting_data` to it; the variable names expected by the code are listed in
  `code/01_build_posting_sample.do` and `code/06_build_figure_sample.do`.

