*==============================================================================*
*  Wang, Zhang, and Liao (2026)
*  "Remote Work and Hiring"  --  Administrative Science Quarterly
*
*  MASTER REPLICATION SCRIPT
*
*  Running this file reproduces every table and figure in the paper, in order:
*     Tables 1-4  (job-posting analyses)
*     Figures 1-5 (job-posting descriptives and mechanism tests)
*     Figure 6 & Table 6 (online experiment)
*
*  ---------------------------------------------------------------------------
*  BEFORE RUNNING
*  ---------------------------------------------------------------------------
*  1. Set $reproot below to the folder where this package is located.
*  2. Set $posting_data below to your copy of the restricted job-posting file.
*     The Burning Glass / Lightcast job-posting data are proprietary and CANNOT
*     be redistributed, so they are NOT included in this package. Steps that need
*     them (01, and Tables/Figures built from the posting sample) require access
*     to the licensed data. The online-experiment data ARE included, so Figure 6
*     and Table 6 replicate out of the box.
*  3. Required Stata packages (install once):
*        ssc install reghdfe,   replace
*        ssc install ivreghdfe,  replace
*        ssc install ftools,     replace
*        ssc install estout,     replace
*        ssc install cibar,      replace
*==============================================================================*

clear all
set more off

* ---- EDIT THESE TWO PATHS -------------------------------------------------- *
global reproot      "/path/to/Remote_work_Hiring_2026_replication"
global posting_data "/path/to/BGT_EU_nomissing_company.dta"
* ---------------------------------------------------------------------------- *

do "$reproot/code/_config.do"

*---------------------------------------------------------------------------*
* Job-posting analyses (require the restricted posting data)
*---------------------------------------------------------------------------*
do "$code/01_build_posting_sample.do"
do "$code/02_table1_hiring_requirements.do"
do "$code/03_table2_iv_estimates.do"
do "$code/04_table3_skill_categories.do"
do "$code/05_table4_salary.do"

do "$code/06_build_figure_sample.do"
do "$code/07_figure1_remote_by_month.do"
do "$code/08_figure2_remote_by_country.do"
do "$code/09_figure3_remote_by_occupation.do"
do "$code/10_figure4_descriptive.do"
do "$code/11_figure5_mechanisms.do"

*---------------------------------------------------------------------------*
* Online experiment (data included in this package)
*---------------------------------------------------------------------------*
do "$code/12_figure6_table6_experiment.do"

di as result "Replication complete. See output/tables and output/figures."
