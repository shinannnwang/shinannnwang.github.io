/*******************************************************************************
	
		foundational_trust_main.do
		1.10.2024
		Main analysis for:
		"Trusting Talent: Cross-Country Differences in Hiring"
		Letian (LT) Zhang and Shinan Wang
		
*******************************************************************************/

global dir "/export/projects4/lzhang_burning_glass_project/BGT_Global/Social_trust"
cd "$dir"

use BGT_Global.dta, clear

*Table 2---Local model
*full sample
reg fundamental_survey_score trust2 i.year_grab_date i.month_grab_date if BGcompanyid~=., cluster(idcountry2)
est store e1
areg fundamental_survey_score trust2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date if BGcompanyid~=., a(esco_level_4) cluster(idcountry2)
est store e2
areg fundamental_survey_score trust2 college graduate sc_tertiary non_tertiary  workexperience3 HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate logjob_total_skill i.year_grab_date i.month_grab_date if BGcompanyid~=., a(esco_level_4_s) cluster(idcountry2)
est store e3
*with orbis
areg fundamental_survey_score trust2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date, a(parent_companyid) cluster(idcountry2)
est store e4
reghdfe fundamental_survey_score trust2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date, a(esco_level_4 parent_companyid) cluster(idcountry2)
est store e5
areg fundamental_survey_score trust2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date, a(esco_level_4_parentid) cluster(idcountry2)
est store e6
areg fundamental_survey_score trust2  HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date, a(esco_level_4_parentid) cluster(idcountry2)
est store e7


estadd local yfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7
estadd local mfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7
estadd local jfixed "Yes", replace: e2 e5
estadd local jsfixed "Yes", replace: e3
estadd local jpsfixed "Yes", replace: e6 e7
estadd local ffixed "Yes", replace: e4 e5

esttab e1 e2 e3 e4 e5 e6 e7 using fundamental_survey_skills_full.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:local} Linear Estimation Predicting Preference for Foundational Skills: Evidence from Cross-Country Job Postings") ///
mgroups("Complete Sample" "Matched Sample (With Orbis)", pattern(1 0 0 1 0 0 0)  prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(trust2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill  HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate  ) ///
order(trust2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill loggdp_per_capita2 HCI2  rule_of_law  unemployment_rate upper_secondary_vocation_rate collective_bargin  ) ///
scalar("hello Fixed Effects:" ///
"yfixed Posting Year" ///
"mfixed Posting Month" ///
"jfixed Occupation" ///
"jsfixed Occupation x Sector" ///
"ffixed Employer" ///
"jpsfixed Occupation x Employer" ///
)

*Table 3---Bilateral model
reg fundamental_survey_score HQ_BGTavg_trust_final  i.idcountry2   if iso3!=HQiso3, cluster(country_pair)
est store e1
areg fundamental_survey_score HQ_BGTavg_trust_final  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2   if iso3~=HQiso3, a(esco_level_4) cluster(country_pair)
est store e2
areg fundamental_survey_score HQ_BGTavg_trust_final  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2   if iso3!=HQiso3, a(parent_companyid) cluster(country_pair)
est store e3
reghdfe fundamental_survey_score HQ_BGTavg_trust_final  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2   if iso3~=HQiso3 , a(esco_level_4 parent_companyid) cluster(country_pair)
est store e4
areg fundamental_survey_score HQ_BGTavg_trust_final college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2   if iso3~=HQiso3, a(esco_level_4_parentid) cluster(country_pair)
est store e5
areg fundamental_survey_score HQ_BGTavg_trust_final logdiff_gdp  law log_distw  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2   if iso3~=HQiso3, a(esco_level_4_parentid) cluster(country_pair)
est store e6
areg HQ_BGTavg_trust_final som_dist2  logdiff_gdp law log_distw  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 if  iso3!=HQiso3 & !missing(fundamental_survey_score), a(esco_level_4_parentid) cluster(country_pair)
est store e7
gen iv_sample = 1 if e(sample)==1
predict HQ_BGTavg_trust_finalhat, xb
areg fundamental_survey_score HQ_BGTavg_trust_finalhat logdiff_gdp law log_distw  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 if iso3!=HQiso3 & iv_sample==1, a(esco_level_4_parentid) cluster(country_pair)
est store e8

estadd local yfixed "Yes", replace: e1 e2 e3 e4 e5 e6  e7 e8
estadd local mfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8
estadd local lcfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8
estadd local jfixed "Yes", replace: e2 e4
estadd local jpsfixed "Yes", replace: e5 e6 e7 e8
estadd local ffixed "Yes", replace: e3 e4

esttab e1 e2 e3 e4 e5 e6 e7 e8 using fundamental_survey_bilateral_skills2.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:bilateral} Linear Estimation Predicting Preference for Foundational Skills: Evidence from Job Postings in Foreign Subsidiaries") ///
mgroups("OLS" "IV", pattern(1 0 0 0 0 0 1 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(HQ_BGTavg_trust_final HQ_BGTavg_trust_finalhat som_dist2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill logdiff_gdp law log_distw comlang_off ) ///
order(HQ_BGTavg_trust_final  HQ_BGTavg_trust_finalhat som_dist2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill logdiff_gdp law comlang_off log_distw ) ///
scalar("hello Fixed Effects:" ///
"yfixed Posting Year" ///
"mfixed Posting Month" ///
"lcfixed Local Country" ///
"jfixed Occupation" ///
"ffixed Employer" ///
"jpsfixed Occupation x Employer" ///
)
eststo clear

*Table 4 --- Moderator
gen college_degree =1 if ideducational_level>=6 & ideducational_level<=8
replace college_degree = 0 if college_degree==. & !missing( ideducational_level)
label var college_degree "Req. College Degree and Above"
foreach var of varlist college_degree jobzone workexperience3 cert_esco4_iso3{
gen trust_`var'	= trust2* `var'
}
foreach var of varlist college_degree jobzone workexperience3 cert_esco4_iso3{
gen HQ_BGT_trust_`var'	= HQ_BGTavg_trust_final* `var'
}
rename trust_cert_esco4_iso3 trust_cert
rename HQ_BGT_trust_cert_esco4_iso3 HQ_BGT_trust_cert
label var HQ_BGT_trust_college_degree "Social Trust (HQ-Local) x Req. College Degree and Above"
label var HQ_BGT_trust_jobzone "Social Trust (HQ-Local) x Job Preparation Level"
label var HQ_BGT_trust_workexperience3 "Social Trust (HQ-Local) x Req. Work Experience"
label var HQ_BGT_trust_cert "Social Trust (HQ-Local) x Occupational Certificates"
label var trust_college_degree "Social Trust (Local Country) x Req. College Degree and Above"
label var trust_jobzone "Social Trust (Local Country) x Job Preparation Level"
label var trust_workexperience3 "Social Trust (Local Country) x Req. Work Experience"
label var trust_cert "Social Trust (Local Country) x Occupational Certificates"
areg fundamental_survey_score trust2 college_degree trust_college_degree    workexperience3 trust_workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date, a(esco_level_4_parentid) cluster(idcountry2)
est store e1
areg fundamental_survey_score trust2 college_degree trust_college_degree    workexperience3 trust_workexperience3  HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate  logjob_total_skill i.year_grab_date i.month_grab_date , a(esco_level_4_parentid) cluster(idcountry2)
est store e2
areg fundamental_survey_score trust2 c.jobzone trust_jobzone  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date, a(esco_level_4_parentid) cluster(idcountry2)
est store e3
areg fundamental_survey_score trust2 c.jobzone trust_jobzone  HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date , a(esco_level_4_parentid) cluster(idcountry2)
est store e4
areg fundamental_survey_score HQ_BGTavg_trust_final  college_degree HQ_BGT_trust_college_degree  workexperience3 HQ_BGT_trust_workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2  if iso3~=HQiso3, a(esco_level_4_parentid) cluster(country_pair)
est store e5
areg fundamental_survey_score HQ_BGTavg_trust_final  logdiff_gdp law log_distw college_degree HQ_BGT_trust_college_degree  workexperience3 HQ_BGT_trust_workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2  if iso3~=HQiso3 , a(esco_level_4_parentid) cluster(country_pair)
est store e6
areg fundamental_survey_score HQ_BGTavg_trust_final  c.jobzone HQ_BGT_trust_jobzone college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2  if iso3~=HQiso3, a(esco_level_4_parentid) cluster(country_pair)
est store e7
areg fundamental_survey_score HQ_BGTavg_trust_final  c.jobzone HQ_BGT_trust_jobzone  logdiff_gdp law log_distw  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2  if iso3~=HQiso3 , a(esco_level_4_parentid) cluster(country_pair)
est store e8
estadd local yfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8
estadd local mfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8
estadd local jpsfixed "Yes", replace:  e1 e2 e3 e4 e5 e6 e7 e8
estadd local lcfixed "Yes", replace:  e5 e6 e7 e8 
estadd local ccfixed "Included", replace:  e2 e4
estadd local bcfixed "Included", replace:  e6 e8
esttab e1 e2 e3 e4 e5 e6 e7 e8 using moderator_combine2.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:moderator_combined} Linear Estimation Predicting Preference for Fundamental Skils: The Moderating Effect") ///
mgroups("Local Model" "Bilateral Model", pattern(1 0 0 0 1 0 0 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(trust2 trust_college_degree trust_workexperience3 trust_jobzone HQ_BGTavg_trust_final  HQ_BGT_trust_college_degree HQ_BGT_trust_workexperience3 HQ_BGT_trust_jobzone college_degree  workexperience3 logjob_total_skill) ///
order(trust2 trust_college_degree trust_workexperience3 trust_jobzone HQ_BGTavg_trust_final  HQ_BGT_trust_college_degree HQ_BGT_trust_workexperience3 HQ_BGT_trust_jobzone college_degree  workexperience3 logjob_total_skill) ///
scalar("hello Fixed Effects:" ///
"yfixed Posting Year" ///
"mfixed Posting Month" ///
"jpsfixed Occupation x Employer" ///
"lcfixed Local Country" ///
"ccfixed Country-Level Controls" ///
"bcfixed Bilateral Country-Level Controls" ///
)
eststo clear


*********************************** Validation ****************************************
*Figure 2 --- map
use "BGTfirm_count.dta"
merge 1:m country_name using /Users/shwang/Desktop/trust_contractor/validation/map/idfile.dta
spmap na_id_world using "coord_mercator_europe.dta", id(na_id_world) fcolor(Blues)
graph export "map_local.eps", as(eps) name("Graph") preview(off) 
use "HQfirm_count.dta"
merge 1:m iso3 using /Users/shwang/Desktop/trust_contractor/validation/map/idfile.dta
spmap na_id_world using "coord_mercator_world.dta", id(na_id_world) fcolor(Blues)
graph export "map_HQ.eps", as(eps) name("Graph") preview(off) 

*Figure 3 ---Sample Distribution by Country
graph bar pct_job_vacancies_stock pct_bgt_jobs pct_Orbis_jobs, over(countryname,label(labsize(vsmall) angle(45))) graphregion(color(white)) ytitle("Country Proportion (%)") legend(label(1 "Official Job Vacancy Statistics") label(2 "Complete Lightcast Sample") label(3 "Matched Lightcast-Orbis Sample")) bar(1, color(black)) bar(2, color(gray)) bar(3, color(gs12))
graph export "bar_job_vacancies.eps", as(eps) name("Graph") preview(off)

*Figure 4 ---Sample Distribution by Industry

graph bar pct_total pct_BGT_total pct_BGT_orbis_total if label_macro_sector!="Mining & Quarrying"&label_macro_sector!="Act. Extra Org & Bodies"&label_macro_sector!="Act. HH as Employers", over(label_macro_sector ,label(labsize(vsmall) angle(45))) graphregion(color(white)) ytitle("Industry Proportion (%)") legend(off) bar(1, color(black)) bar(2, color(gray)) bar(3, color(gs12))
graph export "bar_industry.eps", as(eps) name("Graph") preview(off)

*Sample Distribution by Occupation
graph bar pct_employment pct_BGT_jobs pct_Orbis_jobs, over(isco08,label(labsize(vsmall) angle(45))) graphregion(color(white)) ytitle("Occupation Proportion (%)") legend(label(1 "Official Job Vacancy Statistics") label(2 "Complete Lightcast Sample") label(3 "Matched Lightcast-Orbis Sample")) bar(1, color(black)) bar(2, color(gray)) bar(3, color(gs12))
graph export "bar_occupations.eps", as(eps) name("Graph") preview(off) 


*Figure 5 ---Social Trust by Country
graph box nuts2_trust2_combined, over(countryname, sort(1) label(labsize(small) angle(45))) nooutsides  ytitle("Level of Social Trust", size(medlarge)) graphregion(color(white)) legend(off) note("")
graph export "box_region_trust.eps", as(eps) name("Graph") preview(off) 

*Figure 6 ---Bilateral Trust by Country
graph box HQ_BGTavg_trust_final, over(HQcountryname, sort(1) label(labsize(small) angle(45))) nooutsides  ytitle("Level of Bilateral Trust", size(medlarge)) graphregion(color(white)) legend(off) note("")
graph export "box_bilateral_trust.eps", as(eps) name("Graph") preview(off) 


*Figure 7 ---descriptive (local trust)
collapse fundamental_survey_score trust2 (sum)tag, by(iso3 countryname) fast
twoway (scatter fundamental_survey_score trust2 [fweight = tag] ,  mcolor(black) msymbol(Oh)) (scatter fundamental_survey_score trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit fundamental_survey_score trust2  [fweight = tag]), xtitle("Social Trust (Local Country)", size(medlarge)) ytitle("Preference for Foundational Skills", size(medlarge)) graphregion(color(white)) legend(off)
graph export "graph_fundamental_skills.eps", as(eps) name("Graph") preview(off) 

*Figure 8 ---descriptive (bilateral trust)
binscatter fundamental_survey_score HQ_BGTavg_trust_final if iso3!=HQiso3, nq(70) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Social Trust (HQ Country to Local Country)", size(medlarge)) ytitle("Preference for Foundational Skills", size(medlarge))
graph export "graph_bilateral_fundamental_skills.eps", as(eps) name("Graph") preview(off) 

*********************************** Online Appendix Section ****************************************

*Figure A.1 ---Number of Job Postings by Quarter
twoway (connected bgt_college_jobs_Employer quarter) (connected job_vacancies_stock quarter), graphregion(color(white)) xlabel(1(1)13, angle(45) valuelabel) xtitle("College Jobs") ytitle("Num of Job Vacancies", size(med)) legend(label(1 "Lightcast Global Jobs") label(2 "Official JVS"))
graph export "bgt_jvs_college.eps", as(eps) name("Graph") preview(off)

twoway (connected bgt_noncollege_jobs_Employer quarter) (connected job_vacancies_stock quarter), graphregion(color(white)) xlabel(1(1)13, angle(45) valuelabel) xtitle("Non-College Jobs") ytitle("Num of Job Vacancies", size(med)) legend(label(1 "Lightcast Global Jobs") label(2 "Official JVS"))
graph export "bgt_jvs_noncollege.eps", as(eps) name("Graph") preview(off)

*Figure C.2 ---Validating Lightcast Skills with O*NET ratings
binscatter  max_quality_control LV_QualityControlAnalysis, mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Quality Control Analysis (O*NET)", size(large)) ytitle("Prop. Jobs Req. Quality Control Analysis(BGT)", size(medlarge)) text(0.2 3 "{&rho} =0.44", color(red))
graph save "Graph" "validation_quality_control_analysis.gph"


binscatter  max_quality_control LV_QualityControlAnalysis, mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Quality Control Analysis (O*NET)", size(large)) ytitle("Prop. Jobs Req. Quality Control Analysis(Lightcast)", size(medlarge)) text(0.2 3 "{&rho} =0.44", color(red))
graph save "Graph" "validation_quality_control_analysis.gph"

binscatter   max_maintenance LV_EquipmentMaintenance, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Equipment Maintenance (O*NET)", size(large)) ytitle("Prop. Jobs Req. Equipment Maintenance (Lightcast)", size(medlarge)) text(0.1 3.5 "{&rho} =0.45", color(red))
graph save "Graph" "validation_equipment_maintenance.gph"

binscatter max_technology_design LV_TechnologyDesign, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Technology Design (O*NET)", size(large)) ytitle("Prop. Jobs Req. Technology Design (Lightcast)", size(medlarge)) text(0.17 2.5 "{&rho} =0.37", color(red))
graph save "Graph" "validation_technology_design.gph"

binscatter max_technology_design LV_TechnologyDesign, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Technology Design (O*NET)", size(medlarge)) ytitle("Prop. Jobs Req. Technology Design (Lightcast)", size(medlarge)) text(0.17 2.5 "{&rho} =0.37", color(red))
graph save "Graph" "validation_technology_design.gph"

binscatter max_time_management LV_TimeManagement, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Time Management (O*NET)", size(large)) ytitle("Prop. Jobs Req. Time Management (Lightcast)", size(medlarge)) text(0.2 3.5 "{&rho} =0.35", color(red))
graph save "Graph" "validation_time_management.gph"

binscatter max_persuasion LV_Persuasion, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Persuasion (O*NET)", size(large)) ytitle("Prop. Jobs Req. Persuasion (Lightcast)", size(medlarge)) text(0.004 3.5 "{&rho} =0.33", color(red))
graph save "Graph" "validation_time_management.gph"


binscatter max_decision_making LV_JudgmentandDecisionMaking, nq(20) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Decision Making (O*NET)", size(large)) ytitle("Prop. Jobs Decision Making (Lightcast)", size(medlarge)) text(0.006 4 "{&rho} =0.33", color(red))
graph save "Graph" "validation_decision_making.gph"

binscatter max_social_perceptiveness LV_SocialPerceptiveness, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Social Perceptiveness (O*NET)", size(large)) ytitle("Prop. Jobs Req. Social Perceptiveness (Lightcast)", size(medlarge)) text(0.08 4 "{&rho} =0.38", color(red))
graph save "Graph" "validation_social_perceptiveness.gph"


binscatter max_service_orientation LV_ServiceOrientation, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Service Orientation (O*NET)", size(large)) ytitle("Prop. Jobs Req. Service Orientation (Lightcast)", size(medlarge)) text(0.08 3.5 "{&rho} =0.31", color(red))
graph save "Graph" "validation_service_orientation.gph"

binscatter max_time_management LV_TimeManagement, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Time Management (O*NET)", size(large)) ytitle("Prop. Jobs Req. Time Management (Lightcast)", size(medlarge)) text(0.15 3.5 "{&rho} =0.35", color(red))
graph save "Graph" "validation_service_orientation.gph"

binscatter max_instructing2 LV_Instructing, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Instructing (O*NET)", size(large)) ytitle("Prop. Jobs Req. Instructing (Lightcast)", size(medlarge)) text(0.04 3.5 "{&rho} =0.30", color(red))
graph save "Graph" "validation_service_orientation.gph"


binscatter max_installation LV_Installation, nq(80) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Installation (O*NET)", size(medlarge)) ytitle("Prop. Jobs Req. Installation (Lightcast)", size(medlarge)) text(0.03 2.5 "{&rho} =0.25", color(red))
graph save "Graph" "validation_installation.gph"

binscatter max_negotiation LV_Negotiation, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Negotiation (O*NET)", size(medlarge)) ytitle("Prop. Jobs Req. Negotiation (Lightcast)", size(medlarge)) text(0.05 3.5 "{&rho} =0.43", color(red))
graph save "Graph" "validation_negotiation.gph"


binscatter max_personnel_resouces LV_MgmtofPersonnelResources, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Mgmt of Personnel Resources (O*NET)", size(large)) ytitle("Prop. Jobs Req. Mgmt of Personnel Resources (Lightcast)", size(medlarge)) text(0.13 3.5 "{&rho} =0.31", color(red))
graph save "Graph" "validation_personnel_resources.gph"


binscatter max_financial_resource LV_MgmtofFinancialResources, nq(30) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Mgmt of Financial Resources (O*NET)", size(medlarge)) ytitle("Prop. Jobs Req. Mgmt of Financial Resources (Lightcast)", size(medlarge)) text(0.13 3.5 "{&rho} =0.23", color(red))
graph save "Graph" "validation_negotiation.gph"

*Figure C.3 Skill Preference by Occupation
collapse (p25)fundamental_survey_score25 = fundamental_survey_score (p50)fundamental_survey_score50 = fundamental_survey_score (p75)fundamental_survey_score75 = fundamental_survey_score if idesco_level_4==7412, by(countryname) fast
reshape long fundamental_survey_score, i(countryname) j(percentage)
graph box fundamental_survey_score, over(countryname, sort(1) label(labsize(small) angle(45))) nooutsides  ytitle("Preference for Foundational Skills: Electrical mechanics", size(medlarge)) graphregion(color(white)) legend(off) note("")
graph export "box_foundational_electrical_mechanics", as(eps) name("Graph") preview(off) 


collapse (p25)fundamental_survey_score25 = fundamental_survey_score (p50)fundamental_survey_score50 = fundamental_survey_score (p75)fundamental_survey_score75 = fundamental_survey_score if idesco_level_4==3343, by(countryname) fast
reshape long fundamental_survey_score, i(countryname) j(percentage)
graph box fundamental_survey_score, over(countryname, sort(1) label(labsize(small) angle(45))) nooutsides  ytitle("Preference for Foundational Skills: Executive secretaries", size(medlarge)) graphregion(color(white)) legend(off) note("") 
graph export "box_foundational_executive_secretaries", as(eps) name("Graph") preview(off) 


collapse (p25)fundamental_survey_score25 = fundamental_survey_score (p50)fundamental_survey_score50 = fundamental_survey_score (p75)fundamental_survey_score75 = fundamental_survey_score if idesco_level_4==5223, by(countryname) fast
reshape long fundamental_survey_score, i(countryname) j(percentage)
graph box fundamental_survey_score, over(countryname, sort(1) label(labsize(small) angle(45))) nooutsides  ytitle("Preference for Foundational Skills: Shop sales assistant", size(medlarge)) graphregion(color(white)) legend(off) note("") 
graph export "box_foundational_shop_sales", as(eps) name("Graph") preview(off) 


*Figure D.1: Validating Foundational Skills---Work Experience
use BGT_global_idskill.dta
merge m:1 general_id using jobzone_byid.dta
drop if _merge==2
drop _merge
merge m:1 general_id using /export/projects4/lzhang_burning_glass_project/BGT_Global/Shinan/Social_trust/round3/workexperience_byid.dta
drop if _merge==2
drop _merge
collapse jobzone idexperience3, by( idescoskill_level_3) fast
merge 1:1 idescoskill_level_3 using survey_fundamental_R2.dta
drop _merge
save fundamental_skill_validation
binscatter idexperience3 fundamental_survey_score , nq(80) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Foundational Score", size(medlarge)) ytitle("Years of Work Experience", size(medlarge)) text(2.8 4 "{&rho} =-0.14", color(red))
graph export "foundational_workexp_skill_validation.eps", as(eps) name("Graph") preview(off)

*Figure D.2 Validating Foundational Skills---Job Zone
binscatter jobzone fundamental_survey_score , nq(80) mcolor(black) msymbol(circle_hollow) lcolor(gs10) ylabel(, nogrid) graphregion(style(none) color(gs16)) xtitle("Foundational Score", size(medlarge)) ytitle("Level of Job Zone", size(medlarge)) text(3.7 3.5 "{&rho} =-0.26", color(red))
graph export "foundational_jobzone_skill_validation.eps", as(eps) name("Graph") preview(off)

*Figure E.1: Comparing EVS and WVS
collapse trust trust2, by(iso3)
twoway (scatter trust trust2, mlabel(iso3) mlabcolor(black) mcolor(black) msymbol(Oh))(lfit trust trust2 ), xtitle("Social Trust Score (EVS)", size(medlarge)) ytitle("Social Trust Score (WVS)", size(medlarge)) graphregion(color(white)) legend(off) text(0.6 0.5  "{&rho} =0.92", color(red))
graph export "graph_evs_wvs.eps", as(eps) name("Graph") preview(off)


*Figure E.2: Temporal Trend in Social Trust
rename trust2 trust_iso3
merge 1:m iso3 using EVS_trust_years
drop if _merge==2
drop _merge
keep iso3 years trust2 trust_iso3
rename years year
reshape wide trust2, i(iso3) j(year)
twoway (scatter trust21980 trust22010 , mlabel(iso3) mlabcolor(black) mcolor(black) msymbol(Oh))(lfit trust21980 trust22010 ), xtitle("Social Trust Score 2010s (EVS)", size(medlarge)) ytitle("Social Trust Score 1980s (EVS)", size(medlarge)) graphregion(color(white)) legend(off) text(0.6 0.5  "{&rho} =0.92", color(red))
graph export "graph_evs1980_2010", as(eps) name("Graph") preview(off)



*Table E.1: Using Trust Game Measures (remove trust measure from Croatia, as only 1 respondent)

label var trust_game "Social Trust: Trust Game Measure"
*complete sample
reg fundamental_survey_score trust_game i.year_grab_date i.month_grab_date if BGcompanyid~=. & iso3!="HRV", cluster(idcountry2)
est store e1
areg fundamental_survey_score trust_game college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date if BGcompanyid~=. & iso3!="HRV", a(esco_level_4) cluster(idcountry2)
est store e2
areg fundamental_survey_score trust_game college graduate sc_tertiary non_tertiary  workexperience3 HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate logjob_total_skill i.year_grab_date i.month_grab_date if BGcompanyid~=.& iso3!="HRV", a(esco_level_4_s) cluster(idcountry2)
est store e3
*with orbis
areg fundamental_survey_score trust_game college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date if iso3!="HRV", a(parent_companyid) cluster(idcountry2)
est store e4
reghdfe fundamental_survey_score trust_game college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date if iso3!="HRV", a(esco_level_4 parent_companyid) cluster(idcountry2)
est store e5
areg fundamental_survey_score trust_game college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date if iso3!="HRV", a(esco_level_4_parentid) cluster(idcountry2)
est store e6
areg fundamental_survey_score trust_game  HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date if iso3!="HRV", a(esco_level_4_parentid) cluster(idcountry2)
est store e7


estadd local yfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7
estadd local mfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7
estadd local jfixed "Yes", replace: e2 e5
estadd local jsfixed "Yes", replace: e3
estadd local jpsfixed "Yes", replace: e6 e7
estadd local ffixed "Yes", replace: e4 e5

esttab e1 e2 e3 e4 e5 e6 e7 using fundamental_trust_game.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:trust_game} Linear Estimation Predicting Preference for Foundational Skills: Using Trust Game Measures") ///
mgroups("Complete Sample" "Matched Sample (With Orbis)", pattern(1 0 0 1 0 0 0)  prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(trust_game college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill  HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate  ) ///
order(trust_game college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill loggdp_per_capita2 HCI2  rule_of_law  unemployment_rate upper_secondary_vocation_rate collective_bargin  ) ///
scalar("hello Fixed Effects:" ///
"yfixed Posting Year" ///
"mfixed Posting Month" ///
"jfixed Occupation" ///
"jsfixed Occupation x Sector" ///
"ffixed Employer" ///
"jpsfixed Occupation x Employer" ///
)

*Figure F.1:
gen years = 1970 if year==1970|year==1976
replace years = 1990 if year>=1990 & year<=1996
keep if !missing(years)
keep years USA3 RUS3 ITA3 DEU3 FRA3 CHN3 GBR3 CHE3 IRL3 BEL3 LUX3 NLD3 DNK3 ESP3 GRC3 PRT3 JPN3 TUR3 DEW3 POL3 HUN3 ROU3 CZE3 DEE3 BGR3 YUG3 AUT3 FIN3 SWE3 NOR3 SVK3 isocntry
collapse USA3 RUS3 ITA3 DEU3 FRA3 CHN3 GBR3 CHE3 IRL3 BEL3 LUX3 NLD3 DNK3 ESP3 GRC3 PRT3 JPN3 TUR3 DEW3 POL3 HUN3 ROU3 CZE3 DEE3 BGR3 YUG3 AUT3 FIN3 SWE3 NOR3 SVK3, by(isocntry years)
rename isocntry iso2
rename * C_*
rename C_iso2 iso2
rename C_years years
reshape long C_, i(iso2 years) j(j) string
rename C_ bilateral_trust
 reshape wide bilateral_trust, i(iso2 j) j(year)
 replace iso2 = substr(iso2,1,2)
collapse bilateral_trust1970 bilateral_trust1990, by(iso2 j)
corr bilateral_trust1970 bilateral_trust1990
twoway (scatter bilateral_trust1970 bilateral_trust1990, mcolor(black) msymbol(Oh))(lfit bilateral_trust1970 bilateral_trust1990 ), xtitle("Bilateral Trust:1990s", size(medlarge)) ytitle("Bilateral Trust: 1970s", size(medlarge)) graphregion(color(white)) legend(off) text(3.3 3  "{&rho} =0.9", color(red)) xscale(r(2 3.5))
graph save "Graph" "bilateral_avgtrust_1970_90s.eps", replace
*Figure F.2: Correlation between Eurobarometer Bilateral Trust and Self-administered Bilateral Trust Survey
keep  HQ_BGTavg_trust2022 HQ_BGTavg_trust_final iso3 HQiso3
drop if missing( HQ_BGTavg_trust2022) | missing( HQ_BGTavg_trust_final)
collapse  HQ_BGTavg_trust2022 HQ_BGTavg_trust_final , by(iso3 HQiso3) fast
twoway (scatter HQ_BGTavg_trust_final HQ_BGTavg_trust2022  , mcolor(black) msymbol(Oh))(lfit HQ_BGTavg_trust_final HQ_BGTavg_trust2022 ), xtitle("Bilateral Trust: Self-administered Survey", size(medlarge)) ytitle("Bilateral Trust: Eurobarometer", size(medlarge)) graphregion(color(white)) legend(off) text(3.5 3.5  "{&rho} =0.6", color(red)) xscale(r(2 4)) 
graph export "bilateral_avgtrust_eurobarometer_prolific", as(eps) name("Graph") preview(off)


*Table F.1: Using Self-administered Bilateral Trust Survey
reg fundamental_survey_score HQ_BGTavg_trust2022  i.idcountry2 i.HQ_country2 if iso3!=HQiso3, cluster(country_pair)
est store e1
areg fundamental_survey_score HQ_BGTavg_trust2022  college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 i.HQ_country2 if iso3~=HQiso3, a(esco_level_4) cluster(country_pair)
est store e2
areg fundamental_survey_score HQ_BGTavg_trust2022  college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 i.HQ_country2 if iso3!=HQiso3, a(parent_companyid) cluster(country_pair)
est store e3
reghdfe fundamental_survey_score HQ_BGTavg_trust2022  college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 i.HQ_country2 if iso3~=HQiso3 , a(esco_level_4 parent_companyid) cluster(country_pair)
est store e4
areg fundamental_survey_score HQ_BGTavg_trust2022 college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 i.HQ_country2 if iso3~=HQiso3, a(esco_level_4_parentid) cluster(country_pair)
est store e5
areg fundamental_survey_score HQ_BGTavg_trust2022 logdiff_gdp law log_distw  college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 i.HQ_country2 if iso3~=HQiso3, a(esco_level_4_parentid) cluster(country_pair)
est store e6
areg HQ_BGTavg_trust2022 som_dist2  logdiff_gdp law log_distw  college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 if  iso3!=HQiso3 & !missing(fundamental_survey_score), a(esco_level_4_parentid) cluster(country_pair)
est store e7
gen iv_sample2 = 1 if e(sample)==1
predict HQ_BGTavg_trust2022hat, xb
areg fundamental_survey_score HQ_BGTavg_trust2022hat logdiff_gdp law log_distw  college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2 if iso3!=HQiso3 & iv_sample2==1, a(esco_level_4_parentid) cluster(country_pair)
est store e8

estadd local yfixed "Yes", replace: e1 e2 e3 e4 e5 e6  e7 e8
estadd local mfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8
estadd local lcfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8
estadd local jfixed "Yes", replace: e2 e4
estadd local jpsfixed "Yes", replace: e5 e6 e7 e8
estadd local ffixed "Yes", replace: e3 e4

esttab e1 e2 e3 e4 e5 e6 e7 e8 using fundamental_survey_bilateral_survey_skills.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:bilateral2022} Linear Estimation Predicting Preference for Foundational Skills: Using Self-Administered Survey") ///
mgroups("OLS" "IV", pattern(1 0 0 0 0 0 1 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(HQ_BGTavg_trust2022 HQ_BGTavg_trust2022hat som_dist2 college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill logdiff_gdp law log_distw ) ///
order(HQ_BGTavg_trust2022 HQ_BGTavg_trust2022hat som_dist2 college graduate sc_tertiary non_tertiary   workexperience3 logjob_total_skill logdiff_gdp law log_distw ) ///
scalar("hello Fixed Effects:" ///
"yfixed Posting Year" ///
"mfixed Posting Month" ///
"lcfixed Local Country" ///
"jfixed Occupation" ///
"ffixed Employer" ///
"jpsfixed Occupation x Employer" ///
)
eststo clear
*Figure H.1: 
use HQ_effect_survey.dta
rename * A_*
gen id = _n
reshape long A_, i(id) string
drop if missing(A_)
rename A_ answer
gen Yes = 1 if answer_=="Yes"
gen No = 1 if answer=="No"
replace Yes = 0 if Yes==.
replace No = 0 if No==.
graph bar Yes No, over(HQ_question,  label(angle(45) labsize(small))) stack legend(order(1 "Yes" 2 "No")) graphregion(color(white)) blabel(total) bar(1, color(gs10) lcolor(gs0)) bar(2, color(gs16)lcolor(gs0)) 
graph export bar_HQ_effect_survey.eps

*Table H.1: HQ effect
foreach var of varlist log_totaltech_hours4 creativity problem_solving max_communication{
reghdfe `var'   i.year_grab_date i.month_grab_date i.idcountry2 if iso3==HQiso3 , a(e4_p_`var' = esco_level_4_parentid)	
bys parent_companyid esco_level_4: egen e4_p_`var'2 = max( e4_p_`var')
}
rename e4_p_log_totaltech_hours42  esco4_parent_techhours2
rename e4_p_creativity2 esco4_parent_creativity2
rename e4_p_max_communication2 esco4_parent_max_communication2
rename e4_p_problem_solving2 esco4_parent_problem_solving2

egen esco_level_4_s = group(esco_level_4 sector)
egen esco_level_4_s_country_year = group(esco_level_4 sector idcountry2 year_grab_date)

areg log_totaltech_hours4 esco4_parent_techhours2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.idcountry2 if iso3~=HQiso3, a(esco_level_4_s) cluster(idcountry2)
est store e1
areg log_totaltech_hours4 esco4_parent_techhours2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill if iso3~=HQiso3, a(esco4_s_country_year) cluster(idcountry2)
est store e2
areg max_communication esco4_parent_max_communication2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.idcountry2 if iso3~=HQiso3, a(esco_level_4_s) cluster(idcountry2)
est store e3
areg max_communication esco4_parent_max_communication2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill if iso3~=HQiso3, a(esco4_s_country_year) cluster(idcountry2)
est store e4
areg creativity esco4_parent_creativity2  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.idcountry2 if iso3~=HQiso3, a(esco_level_4_s) cluster(idcountry2)
est store e5
areg creativity esco4_parent_creativity2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill if iso3~=HQiso3, a(esco4_s_country_year) cluster(idcountry2)
est store e6
areg problem_solving esco4_parent_problem_solving2  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.idcountry2 if iso3~=HQiso3, a(esco_level_4_s) cluster(idcountry2)
est store e7
areg problem_solving esco4_parent_problem_solving2 college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill if iso3~=HQiso3, a(esco4_s_country_year) cluster(idcountry2)
est store e8

estadd local yfixed "Yes", replace: e1  e3  e5 e7  
estadd local lcfixed "Yes", replace: e1  e3  e5 e7 
estadd local jsfixed "Yes", replace: e1  e3  e5 e7 
estadd local jscyfixed "Yes", replace: e2  e4  e6 e8 

esttab e1 e2 e3 e4 e5 e6 e7 e8 using headquarter_effect_skills2.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:hq_effect} Linear Estimation Predicting Headquarter Effects: Evidence from Job Postings in Foreign Subsidiaries") ///
mgroups("Technical Skills""Social Skills""Creativity Skills""Provlem Solving Skills", pattern(1 0 1 0 1 0 1 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(esco4_parent_techhours2 esco4_parent_max_communication2 esco4_parent_creativity2 esco4_parent_problem_solving2  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill  ) ///
order(esco4_parent_techhours2 esco4_parent_max_communication2 esco4_parent_creativity2 esco4_parent_problem_solving2   college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill  ) ///
scalar("hello Fixed Effects:" ///
"yfixed Posting Year" ///
"lcfixed Local Country" ///
"jsfixed Occupation x Sector" ///
"jscyfixed Occupation x Sector x Country x Year" ///
)
eststo clear

*Table J.1: Moderators ---Occupational Certificates
label var cert_esco4_iso3 "Occupational Certificates"
label var trust_cert "Social Trust (Local Country) x Occupational Certificates"
areg fundamental_survey_score trust2 c.cert_esco4_iso3 trust_cert  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date, a(esco_level_4_parentid) cluster(idcountry2)
est store e1
areg fundamental_survey_score trust2 c.cert_esco4_iso3 trust_cert  HCI2 loggdp_per_capita2 rule_of_law upper_secondary_vocation_rate collective_bargin unemployment_rate college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date , a(esco_level_4_parentid) cluster(idcountry2)
est store e2
areg fundamental_survey_score HQ_BGTavg_trust_final  c.cert_esco4_iso3 HQ_BGT_trust_cert college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2  if iso3~=HQiso3, a(esco_level_4_parentid) cluster(country_pair)
est store e3
areg fundamental_survey_score HQ_BGTavg_trust_final  c.cert_esco4_iso3 HQ_BGT_trust_cert  logdiff_gdp law log_distw  college graduate sc_tertiary non_tertiary  workexperience3 logjob_total_skill i.year_grab_date i.month_grab_date i.idcountry2  if iso3~=HQiso3 , a(esco_level_4_parentid) cluster(country_pair)
est store e4
estadd local yfixed "Yes", replace: e1 e2 e3 e4 
estadd local mfixed "Yes", replace: e1 e2 e3 e4
estadd local jpsfixed "Yes", replace:  e1 e2 e3 e4 
estadd local lcfixed "Yes", replace:  e3 e4 
estadd local ccfixed "Included", replace:  e2 e4 
estadd local jcfixed "Included", replace:  e1 e2 e3 e4 
esttab e1 e2 e3 e4  using moderator_cert.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:moderator_cert} Linear Estimation Predicting Preference for Foundational Skills: Moderator (Occupational Certificates)") ///
mgroups("Local Model" "Bilateral Model", pattern(1 0 1 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(trust2 cert_esco4_iso3 trust_cert HQ_BGTavg_trust_final  HQ_BGT_trust_cert  ) ///
order(trust2 cert_esco4_iso3 trust_cert HQ_BGTavg_trust_final  HQ_BGT_trust_cert) ///
scalar("hello Fixed Effects:" ///
"yfixed Posting Year" ///
"mfixed Posting Month" ///
"jpsfixed Occupation x Employer" ///
"lcfixed Local Country" ///
"ccfixed Country Controls" ///
"jcfixed Job Controls" ///
)
eststo clear


*Figure K.1: Testing Mechanisms: Using LinkedIn data for Organizational Tenure
use experience_final.dta
bys id2: egen max_n_job = max(rn)
replace end_year = 2023 if missing(end_year)&max_n_job==rn
bys id2 employer_id2: egen min_start_year = min(start_year)
bys id2 employer_id2: egen max_end_year = max(end_year)
gen years_at_employer = max_end_year- min_start_year+1
bys id2: egen count_rn = count(rn)
gsort id2 employer_id2 rn
by id2 employer_id2: gen n_job = _n

reg years_at_employer trust i.start_year if start_year>=2000 & start_year<=2023 & years_in_labor_market>=1 & years_in_labor_market<=40 & n_job==1
keep if e(sample)==1
gen tag = 1
collapse years_at_employer trust (sum)tag, by(iso3s) fast
corr years_at_employer trust
decode iso3s,gen(iso3)

twoway (scatter years_at_employer trust [fweight = tag] ,  mcolor(black) msymbol(Oh)) (scatter years_at_employer trust, mlabel(iso3) mlabcolor(black) ms(i))(lfit years_at_employer trust  [fweight = tag]), xtitle("Social Trust (Local Country)", size(medlarge)) ytitle("Organizational Tenure", size(medlarge)) graphregion(color(white)) legend(off)
graph export "linkedin_tenure_trust", as(eps) name("Graph") preview(off)

*Table K.1: Trust Predicting Organizational Tenure
reg years_at_employer trust i.start_year if start_year>=2000 & start_year<=2023 & years_in_labor_market>=1 & years_in_labor_market<=40 & n_job==1, cluster(wk_country4)
est store e1
areg years_at_employer trust qs_ranking_group_final_V2 phd_degree master_degree bachelor_degree  immigrant i.start_year if start_year>=2000 & start_year<=2023 & years_in_labor_market>=1 & years_in_labor_market<=40 & & n_job==1, a(title2_id) cluster(wk_country4)
est store e2
areg years_at_employer trust qs_ranking_group_final_V2 phd_degree master_degree bachelor_degree  immigrant loggdp2010 hci2018 unemployment_year rule_of_law_est2010 i.start_year if start_year>=2000 & start_year<=2023 & years_in_labor_market>=1 & years_in_labor_market<=40 & & n_job==1, a(title2_id) cluster(wk_country4)
est store e3


estadd local yfixed "Yes", replace: e1 e2 e3 
estadd local jfixed "Yes", replace: e2 e3

esttab e1 e2 e3 using linkedin_trust_tenure.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:linkedin} Linear Estimation Predicting Preference for Foundational Skills: Evidence from Cross-Country Job Postings") ///
mgroups("All Countries" , pattern(1 0 0 )  prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(trust qs_ranking_group_final_V2 phd_degree master_degree bachelor_degree  immigrant loggdp2010 hci2018 unemployment_year  ) ///
order(trust qs_ranking_group_final_V2 phd_degree master_degree bachelor_degree  immigrant loggdp2010 hci2018 unemployment_year) ///
scalar("hello Fixed Effects:" ///
"yfixed Starting Year" ///
"jfixed Occupation" ///
"ffixed Employer" ///
"jffixed Occupation-Employer" ///
)


*Figure L.1: Mechanism---Role Flexibility (ESJS Survey)
use "ESJS_data.dta"
gen tag = 1
collapse q8_2 q8_3 q8_5 (sum)tag, by(iso3 trust2)

twoway (scatter q8_2 trust2 [fweight = tag],  mcolor(black) msymbol(Oh)) (scatter q8_2 trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit q8_2 trust2 [fweight = tag]), xtitle("Social Trust (Local Country)", size(medlarge)) ytitle("Moved to Another Unit", size(medlarge)) graphregion(color(white)) legend(off)


twoway (scatter q8_3 trust2 [fweight = tag],  mcolor(black) msymbol(Oh)) (scatter q8_3 trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit q8_3 trust2 [fweight = tag]), xtitle("Social Trust (Local Country)", size(medlarge)) ytitle("Changed Task/Responsibilities", size(medlarge)) graphregion(color(white)) legend(off)

twoway (scatter q8_5 trust2 [fweight = tag],  mcolor(black) msymbol(Oh)) (scatter q8_5 trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit q8_5 trust2 [fweight = tag]), xtitle("Social Trust (Local Country)", size(medlarge)) ytitle("No Role Change", size(medlarge)) graphregion(color(white)) legend(off)

*Table L.1: Mechanism---Role Flexibility (ESJS Survey)
reg q8_2 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e1
reg q8_2 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary   loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e2
reg q8_3 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e3
reg q8_3 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary   loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e4
reg q8_5 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e5
reg q8_5 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e6

estadd local jfixed "Yes", replace: e1 e2 e3 e4 e5 e6 
estadd local sfixed "Yes", replace: e1 e2 e3 e4 e5 e6 
esttab e1 e2 e3 e4 e5 e6 using ESJS_role_flexibility.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:esjs_role} Linear Estimation Predicting Employees Jobs' Role Flexibility: Evidence from ESJS Survey") ///
mgroups("Moved to Another Unit" "Changed Task/Responsibilities" "No Role Change", pattern(1 0 1 0 1 0) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary    loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin) ///
order(trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin) ///
scalar("hello Fixed Effects:" ///
"jfixed Occupation" ///
"sfixed Sector" ///
)
eststo clear


*Figure M.1: Mechanism---Employee Training (ESJS Survey)
use "ESJS_data.dta"
gen tag = 1
gen employer_pay = 1 if q34_2 == 1|q34_3==1
replace employer_pay = 0 if employer_pay==. & !missing(q34_2)
collapse q33_1 q33_2 q33_3 q33_4 employer_pay (sum)tag, by(iso3 trust2)

twoway (scatter q33_1 trust2 [fweight = tag],  mcolor(black) msymbol(Oh)) (scatter training_on_job trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit training_on_job trust2 [fweight = tag]), xtitle("Social Trust (Local Country)", size(huge)) ytitle("Training During Work", size(huge)) graphregion(color(white)) legend(off)
graph export esjs_q33_1_training.eps

twoway (scatter a33_2 trust2 [fweight = tag],  mcolor(black) msymbol(Oh)) (scatter training_off_job trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit training_off_job trust2 [fweight = tag]), xtitle("Social Trust (Local Country)", size(huge)) ytitle("Training outside of Work", size(huge)) graphregion(color(white)) legend(off)
graph export esjs_q33_2_training.eps

twoway (scatter q33_3 trust2 [fweight = tag],  mcolor(black) msymbol(Oh)) (scatter q33_3 trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit q33_3 trust2 [fweight = tag]), xtitle("Social Trust (Local Country)", size(huge)) ytitle("Training while Working", size(huge)) graphregion(color(white)) legend(off)
graph export esjs_q33_3_training.eps

twoway (scatter q33_4 trust2 [fweight = tag],  mcolor(black) msymbol(Oh)) (scatter q33_4 trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit q33_4 trust2 [fweight = tag]), xtitle("Social Trust (Local Country)", size(huge)) ytitle("No Training", size(huge)) graphregion(color(white)) legend(off)
graph export esjs_q33_4_training.eps

twoway (scatter employer_pay trust2 [fweight = tag],  mcolor(black) msymbol(Oh)) (scatter employer_pay trust2, mlabel(iso3) mlabcolor(black) ms(i))(lfit employer_pay trust2 [fweight = tag]), xtitle("Social Trust (Local Country)", size(huge)) ytitle("Employer Paid for Training", size(huge)) graphregion(color(white)) legend(off)
graph export esjs_q34_employer_pay.eps





*Table M.1: Mechanism---Employee Training (ESJS Survey)
reg q33_1 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary     i.esco_level_1 i.industry,  cluster(idcountry2)
est store e1
reg q33_1 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e2
reg q33_2 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e3
reg a33_2 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin i.esco_level_1 i.industry,  cluster(idcountry2)
est store e4
reg q33_3 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e5
reg q33_3 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin i.esco_level_1 i.industry,  cluster(idcountry2)
est store e6
reg q33_4 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary   i.esco_level_1 i.industry,  cluster(idcountry2)
est store e7 
reg q33_4 trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin i.esco_level_1 i.industry,  cluster(idcountry2)
est store e8
reg employer_pay trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary   i.esco_level_1 i.industry,  cluster(idcountry2)
est store e9
reg employer_pay trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin  i.esco_level_1 i.industry,  cluster(idcountry2)
est store e10
estadd local jfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8 e9 e10 
estadd local sfixed "Yes", replace: e1 e2 e3 e4 e5 e6 e7 e8 e9 e10 
esttab e1 e2 e3 e4 e5 e6  e7 e8 e9 e10 using ESJS_survey.tex, replace label se r2 wrap width(\hsize) ///
title("\label{tab:esjs} Linear Estimation Predicting Employees' Training: Evidence from ESJS Survey") ///
mgroups("During Work" "Outside Work" "While Working" "No Training" "Employer Paid", pattern(1 0 1 0 1 0 1 0 1 0 ) prefix(\multicolumn{@span}{c}{) suffix(}) span erepeat(\cmidrule(lr){@span})) ///
nomtitles ///
noomitted keep(trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary   loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin) ///
order(trust2 mrk_age resp_gender years_in_job college graduate sc_tertiary non_tertiary  loggdp_per_capita2 unemployment_rate upper_secondary_vocation_rate rule_of_law collective_bargin) ///
scalar("hello Fixed Effects:" ///
"jfixed Occupation" ///
"sfixed Sector" ///
)
eststo clear
